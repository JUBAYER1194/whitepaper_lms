<template>


            <v-container
                fluid
                fill-height
                flat
            >
                <v-layout
                    align-center
                    justify-center

                >
                    <v-flex
                        xs12
                        sm8
                        md4
                    >
                        <v-card
                            class="elevation-12"
                            flat
                        >
                            <v-toolbar
                                color="#9652ff"
                                dark
                                flat
                            >
                                <v-toolbar-title>Login form</v-toolbar-title>
                                <v-spacer></v-spacer>
                            </v-toolbar>
                            <v-card-text>
                                <v-form
                                >
                                    <v-text-field
                                        label="UserName"
                                        name="login"
                                        prepend-icon="person"
                                        v-model="form.email"
                                        type="text"
                                    ></v-text-field>

                                    <v-text-field
                                        id="password"
                                        label="Password"
                                        name="password"
                                        v-model="form.password"
                                        prepend-icon="lock"
                                        type="password"
                                    ></v-text-field>
                                </v-form>
                            </v-card-text>
                            <v-card-actions>
                                <v-spacer></v-spacer>
                                <v-btn style="background-color:#9652ff;color: white;" type="submit" @click="login">Login</v-btn>
                                <v-btn style="background-color:#9652ff;color: white;" type="submit" @click="signup" >Signup</v-btn>
                            </v-card-actions>
                        </v-card>
                    </v-flex>
                </v-layout>
            </v-container>


</template>

<script>
    export default {
        data ()  {
            return{
                form:{
                    email:null,
                    password:null,
                },


            }

        },
        created(){
            if(User.loggedIn()){
                this.$router.push({name:'home'})
                // window.location = '/'
            }

        },
        methods:{
            login(){
               User.login(this.form)
                //this.$router.push({name:'home'})
            },
            signup(){
                window.location = '/signups'
            }

        },
    }



</script>
